/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projetocellstore;

import model.Acessorio;
import model.Celular;
import model.Cliente;
import model.NotaFiscal;
import model.TipoAcessorio;
import model.Vendedor;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class ProjetoCellStore {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        Acessorio a = new Acessorio(0,"CAPA", TipoAcessorio.CAPA,10 , 5);
        Cliente c = new Cliente("Marcos", "657488907-90","m@gmail.com","(11)94838-4328");
        Celular cl = new Celular(0, "Samsung", "NoteMotoG1000", 1, 1000, 10);
        Acessorio ac = new Acessorio(0, "Fone_BT", TipoAcessorio.FONE_BLUETOOTH, 100, 2);
        Vendedor v = new Vendedor("Carlao", "537679412-39", "c@gmail.com", 1000, 50, 50);
        NotaFiscal n = new NotaFiscal(c, v);
        n.adicionaProduto(cl, 2);
        n.adicionaProduto(ac, 1);
        System.out.println(n);
        
    }
}
