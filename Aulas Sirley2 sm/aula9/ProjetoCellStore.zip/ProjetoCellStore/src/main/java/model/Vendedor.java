/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Vendedor extends Funcionario {
    private double comisao = 0;

    public Vendedor(String nome, String cpf, String email, int codigo, double salarioB , double comisao) {
        super(nome, cpf, email, codigo, salarioB);
        this.comisao = comisao;
    }

    public double getComisao() {
        return comisao;
    }

    public void setComisao(double comisao) {
        this.comisao = comisao;
    }
    
    
}
