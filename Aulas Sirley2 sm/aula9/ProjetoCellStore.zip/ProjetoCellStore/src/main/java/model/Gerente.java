/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Gerente extends Funcionario {
    private double BunosA = 0;

    public Gerente( String nome, String cpf, String email, int codigo, double salarioB ,double BunosA ) {
        super(nome, cpf, email, codigo, salarioB);
        this.BunosA = BunosA;
    }

    public double getBunosA() {
        return BunosA;
    }

    public void setBunosA(double BunosA) {
        this.BunosA = BunosA;
    }
    
    
    
}
