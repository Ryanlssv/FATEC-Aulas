/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FATEC ZONA LESTE
 */
public enum TipoAcessorio { 
CAPA, 
FONE, 
CARREGADOR, 
PELICULA, 
FONE_BLUETOOTH, 
CAPINHA, 
SUPORTE 
}
