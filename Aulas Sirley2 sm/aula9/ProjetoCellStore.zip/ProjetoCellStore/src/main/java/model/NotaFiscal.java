/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class NotaFiscal { 
    private static int contadorNotas = 0; 
    private Cliente cliente; 
    private Vendedor vendedor ; 
    private LocalDateTime data; 
    private ArrayList<Produto> itens= new ArrayList<>(); 
    private double total=0; 
 
    public NotaFiscal (Cliente cliente, Vendedor vendedor) { 
        this.cliente = cliente; 
        this.vendedor = vendedor; 
        this.data = LocalDateTime.now(); 
        contadorNotas++; 
    }
    
      public void adicionaProduto(Produto item,int quantidade) { 
        //falta definir verificação e atualização de estoque 
        itens.add(item); 
        total+= quantidade*item.getPreco(); 
    }
    
      public String gerarNumeroNFe() { 
    // série 001 + número sequencial 
    String serie = "001"; 
    String numero = String.format("%09d", contadorNotas); 
    return "NF" + serie + numero; // Ex: "NF001000000123" 
} 

    public static int getContadorNotas() {
        return contadorNotas;
    }

    public static void setContadorNotas(int contadorNotas) {
        NotaFiscal.contadorNotas = contadorNotas;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public LocalDateTime getData() {
        return data;
    }

    public void setData(LocalDateTime data) {
        this.data = data;
    }

    public ArrayList<Produto> getItens() {
        return itens;
    }

    public void setItens(ArrayList<Produto> itens) {
        this.itens = itens;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
      
      public String toString() { 
      return "************************************************************************" 
      + "\n NotaFiscal. Número "+ gerarNumeroNFe() 
                + "\n " + "Cliente=" + cliente.getNome()  
                + "\n vendedor=" + vendedor.getNome() 
                + "\n Data=" + data  
                + "\n itens=" + itens  
                + "\n Total= R$" + total  
                +"\n ************************************************************************"; 
    }        
}
