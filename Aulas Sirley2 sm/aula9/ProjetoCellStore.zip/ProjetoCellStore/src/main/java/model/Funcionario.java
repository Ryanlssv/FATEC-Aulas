/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FATEC ZONA LESTE
 */
public abstract class Funcionario extends Pessoa {
    private int codigo;
    private double salarioB;

    public Funcionario( String nome, String cpf, String email, int codigo, double salarioB) {
        super(nome, cpf, email);
        this.codigo = codigo;
        this.salarioB = salarioB;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getSalarioB() {
        return salarioB;
    }

    public void setSalarioB(double salarioB) {
        this.salarioB = salarioB;
    }
    
    
}
