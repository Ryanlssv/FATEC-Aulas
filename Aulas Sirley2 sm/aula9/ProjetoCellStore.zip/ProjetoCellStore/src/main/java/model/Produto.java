/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FATEC ZONA LESTE
 */
public abstract class Produto {
    private int codigo;
    private String nome;
    private double preco;
    private int qtdeEstoque;

    public Produto(int codigo, String nome, double preco, int qtdeEstoque) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.qtdeEstoque = qtdeEstoque;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQtdeEstoque() {
        return qtdeEstoque;
    }

    public void setQtdeEstoque(int qtdeEstoque) {
        this.qtdeEstoque = qtdeEstoque;
    }

    @Override
    public String toString() {
        return "\n Produto{" + "codigo=" + codigo + ", nome=" + nome + ", preco= R$: " + preco + ", qtdeEstoque=" + qtdeEstoque + '}';
    }
    
    
    
}
