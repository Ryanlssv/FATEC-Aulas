/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Acessorio extends Produto {
    private TipoAcessorio tipo;

    public Acessorio( int codigo, String nome, TipoAcessorio tipo ,double preco, int qtdeEstoque) {
        super(codigo, nome, preco, qtdeEstoque);
        this.tipo = tipo;
    }

    public TipoAcessorio getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return "Acessorio{" + "tipo=" + tipo + '}';
    }
    
}
