/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Celular extends Produto {
    private String modelo;
    private int Gb;

    public Celular( int codigo, String nome, String modelo, int Gb ,double preco, int qtdeEstoque) {
        super(codigo, nome, preco, qtdeEstoque);
        this.modelo = modelo;
        this.Gb = Gb;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getGb() {
        return Gb;
    }

    public void setGb(int Gb) {
        this.Gb = Gb;
    }

    @Override
    public String toString() {
        return "\n Celular{" + "modelo=" + modelo + ", Gb=" + Gb + '}';
    }
    
    
}
