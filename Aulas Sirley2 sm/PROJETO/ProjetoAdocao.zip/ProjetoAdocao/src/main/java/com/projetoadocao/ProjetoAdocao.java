/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.projetoadocao;

/**
 *
 * @author Pichau
 */
public class ProjetoAdocao {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
