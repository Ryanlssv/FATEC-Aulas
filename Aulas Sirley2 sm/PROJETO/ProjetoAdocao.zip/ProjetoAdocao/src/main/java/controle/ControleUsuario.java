/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

/**
 *
 * @author Pichau
 */
import java.util.*;

import java.util.ArrayList;
import model.Persistencia;

import model.Usuario;




public class ControleUsuario {
    private final String ARQ_USUARIOS = "usuarios.txt";
    private List<Usuario> usuarios = new ArrayList<>();

    public ControleUsuario() {
        carregarUsuarios();
    }

    public void carregarUsuarios() {
        usuarios.clear();
        for (String linha : Persistencia.lerArquivo(ARQ_USUARIOS)) {
            String[] parts = linha.split(";");
            if (parts.length == 3) {
                usuarios.add(new Usuario(parts[0], parts[1], parts[2]));
            }
        }
    }

    public boolean validarLogin(String login, String senha) {
        for (Usuario u : usuarios) {
            if (u.getEmail().equals(login) && u.getSenha().equals(senha)) {
                return true;
            }
        }
        return false;
    }

    public boolean existeLogin(String login) {
        for (Usuario u : usuarios) {
            if (u.getEmail().equals(login)) return true;
        }
        return false;
    }

    public void cadastrarUsuario(Usuario novo) {
        usuarios.add(novo);
        salvar();
    }

    public void salvar() {
        List<String> linhas = new ArrayList<>();
        for (Usuario u : usuarios) linhas.add(u.toString());
        Persistencia.salvarArquivo(ARQ_USUARIOS, linhas);
    }
}

