/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.util.ArrayList;
import java.util.List;
import model.Animal;
import model.Persistencia;

/**
 *
 * @author Pichau
 */
public class ControleAnimal {
    private final String ARQ_ANIMAIS = "animais.txt";
    private List<Animal> animais = new ArrayList<>();
    
    public ControleAnimal(){
        carregarAnimais();
    }
    
    public void carregarAnimais(){
        animais.clear();
        for(String linha : Persistencia.lerArquivo(ARQ_ANIMAIS)){
            String[] parts = linha.split(";");
            if(parts.length == 4){
            try{
              int idade = Integer.parseInt(parts[2]);
              animais.add(new Animal(parts[0],parts[1],idade,parts[3]));    
            } catch (NumberFormatException ex){
            
                }
            }
        }
    } 
    
    public List<Animal> getAnimais(){
        return animais;
    }
    
    public void atualizarStatus(String nome, String novoStatus) {
        for (Animal a : animais) {
            if (a.getNome().equalsIgnoreCase(nome)) {
                a.setStatus(novoStatus);
                break;
            }
        }
        Persistencia.salvarArquivo(animais);
    }
    
    public void salvar(){
        List<String> linhas = new ArrayList<>();
        for(Animal a : animais ) linhas.add(a.toString());
        Persistencia.salvarArquivo(ARQ_ANIMAIS,linhas);
    }
    
}
