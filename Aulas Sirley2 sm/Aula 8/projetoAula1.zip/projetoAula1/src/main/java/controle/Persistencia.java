/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import model.Usuario;

/**
 *
 * @author FATEC ZONA LESTE
 */


public class Persistencia  {
 public static ArrayList<Usuario> lista = new ArrayList<Usuario>();

 public static void cadastrar(Usuario user){

 if( user != null)lista.add(user);
 }

 public static void importar(String nomedoarquivo) {
 // importa do arquivo para ArrayList
 try {
 FileReader arq = new FileReader(nomedoarquivo);
 BufferedReader lerArq = new BufferedReader(arq);
 String nome,email,senha;
 String linha = lerArq.readLine(); // lê a primeira linha
 

while (linha != null) {
 nome= linha;
 email=lerArq.readLine();
 senha=lerArq.readLine();
 lista.add(new Usuario(nome,email,senha));
 linha = lerArq.readLine(); // lê o próximo usuário
 }
 arq.close();
 } catch (IOException e) {
 System.err.printf("Erro na abertura do arquivo: %s.", e.getMessage());
 }
 }
 
 
 
 
}
 